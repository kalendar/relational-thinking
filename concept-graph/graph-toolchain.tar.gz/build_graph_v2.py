#!/usr/bin/env python3
"""
Build the concept knowledge graph for "Relational Thinking" and query it for
prerequisite violations.

Nodes = concepts. Edges = introduced_in / used_in / depends_on / cross_references.
A violation is any depends_on edge (hard) whose target is introduced later than
the chapter that depends on it -- or never introduced at all.
"""
import json, glob, re, os
from collections import defaultdict

ALIASES = {k: v for k, v in json.load(open('/root/audit/aliases.json')).items()
           if not k.startswith('_')}
CHAPTERS = {c['n']: c for c in json.load(open('/root/audit/chapters.json'))}
ADJ = {k: v for k, v in json.load(open('/root/audit/adjudications.json')).items()
       if not k.startswith('_')}


def norm(s):
    s = s.lower().strip()
    s = re.sub(r'[`*_]', '', s)
    s = re.sub(r'\s*\(.*?\)\s*', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    if len(s) > 4 and s.endswith('s') and not s.endswith('ss'):
        s = s[:-1]
    return ALIASES.get(s, s)


nodes = {}


def node(name):
    n = norm(name)
    if n not in nodes:
        nodes[n] = {
            'concept': n, 'surface_forms': set(), 'types': set(),
            'introduced_in': [], 'assumed_in': [], 'in_key_terms_of': [],
        }
    return nodes[n]


cross_refs = []
key_terms_by_ch = {}
outcomes_by_ch = {}

for f in sorted(glob.glob('/root/audit/extractions_v2/chapter-*.json')):
    d = json.load(open(f))
    ch = d['chapter_number']
    key_terms_by_ch[ch] = d.get('key_terms', [])
    outcomes_by_ch[ch] = d.get('learning_outcomes', [])

    for c in d.get('concepts_introduced', []):
        nd = node(c['name'])
        nd['surface_forms'].add(c['name'])
        nd['types'].add(c.get('type', '?'))
        nd['introduced_in'].append({
            'chapter': ch,
            'section': c.get('definition_location'),
            'formal': bool(c.get('formally_defined')),
            'quote': (c.get('definition_quote') or '')[:400],
            'in_key_terms': bool(c.get('in_key_terms')),
        })
        if c.get('in_key_terms'):
            nd['in_key_terms_of'].append(ch)

    for c in d.get('concepts_assumed', []):
        nd = node(c['name'])
        nd['surface_forms'].add(c['name'])
        nd['assumed_in'].append({
            'chapter': ch,
            'section': c.get('used_at'),
            'strength': c.get('strength', 'soft'),
            'glossed_in_place': bool(c.get('glossed_in_place')),
            'quote': (c.get('quote') or '')[:400],
            'why': c.get('why_needed', ''),
        })

    for x in d.get('cross_references', []):
        x['from_chapter'] = ch
        cross_refs.append(x)

# ---------------------------------------------------------------- violations
violations, adjudicated, closed = [], [], []
for n, nd in nodes.items():
    formal_intros = [i['chapter'] for i in nd['introduced_in'] if i['formal']]
    any_intros = [i['chapter'] for i in nd['introduced_in']]
    first_formal = min(formal_intros) if formal_intros else None
    first_any = min(any_intros) if any_intros else None

    for a in nd['assumed_in']:
        if a['strength'] != 'hard':
            continue
        ch = a['chapter']
        handled = a.get('glossed_in_place')
        if first_any is None:
            kind, detail = 'never_introduced', 'assumed but never introduced anywhere in the book'
        elif first_any > ch:
            kind, detail = 'used_before_introduced', f'introduced in ch{first_any}, relied on in ch{ch}'
        elif first_formal is not None and first_formal > ch:
            kind, detail = 'informal_before_formal', f'formally defined ch{first_formal}, relied on ch{ch}'
        else:
            continue
        adj = ADJ.get(f'{n}@{ch}')
        if adj:
            adjudicated.append({'concept': n, 'chapter': ch, 'verdict': adj})
            continue
        if handled:
            closed.append({'concept': n, 'chapter': ch, 'section': a['section'],
                           'quote': a['quote']})
            continue
        violations.append({
            'concept': n, 'kind': kind, 'detail': detail,
            'glossed_in_place': bool(handled),
            'depends_from_chapter': ch, 'section': a['section'],
            'introduced_in_chapter': first_any,
            'quote': a['quote'], 'why': a['why'],
        })

# multiple independent introductions = redundancy / drift risk
redundant = []
for n, nd in nodes.items():
    formal = [i for i in nd['introduced_in'] if i['formal']]
    chs = sorted(set(i['chapter'] for i in formal))
    if len(chs) > 1:
        redundant.append({'concept': n, 'chapters': chs,
                          'quotes': {i['chapter']: i['quote'][:200] for i in formal}})

# defined in Key Terms but never leaned on again anywhere later
orphans = []
for n, nd in nodes.items():
    intros = sorted(set(i['chapter'] for i in nd['introduced_in']))
    if not intros:
        continue
    later_use = [a['chapter'] for a in nd['assumed_in'] if a['chapter'] > max(intros)]
    if nd['in_key_terms_of'] and not later_use and max(intros) < 12:
        orphans.append({'concept': n, 'introduced_in': intros})

# ------------------------------------------------------- cross-ref validation
snap = {}
for n in CHAPTERS:
    p = f'/root/audit/snapshots/chapter-{n:02d}.md'
    snap[n] = open(p, encoding='utf-8').read().lower() if os.path.exists(p) else ''

bad_refs = []
for x in cross_refs:
    tgt = x.get('points_to_chapter')
    concept = (x.get('concept_referenced') or '').strip()
    if not tgt or not concept or tgt not in snap:
        continue
    if x.get('direction') != 'backward':
        continue
    c = norm(concept)
    head = re.sub(r'[^a-z0-9 ]', '', c).split()
    probe = ' '.join(head[:3])
    if probe and probe not in snap[tgt]:
        bad_refs.append({
            'from_chapter': x['from_chapter'], 'location': x.get('location'),
            'claim': x.get('claim_text'), 'concept': concept,
            'points_to_chapter': tgt,
            'issue': f'"{probe}" does not appear in chapter {tgt}',
        })

# ------------------------------------------------------------------- outputs
graph = {
    'book': 'Relational Thinking',
    'source': 'https://pressbooks.marshall.edu/mis340/',
    'chapters': [CHAPTERS[n] for n in sorted(CHAPTERS)],
    'nodes': [
        {**nd, 'surface_forms': sorted(nd['surface_forms']),
         'types': sorted(nd['types'])}
        for nd in sorted(nodes.values(), key=lambda x: x['concept'])
    ],
    'cross_references': cross_refs,
    'findings': {
        'closed_by_inline_gloss': sorted(closed, key=lambda c: c['chapter']),
        'previously_adjudicated': sorted(adjudicated, key=lambda c: c['chapter']),
        'prerequisite_violations': sorted(violations, key=lambda v: (v['depends_from_chapter'], v['concept'])),
        'redundant_introductions': sorted(redundant, key=lambda r: r['chapters']),
        'orphan_concepts': sorted(orphans, key=lambda o: o['concept']),
        'dangling_cross_references': bad_refs,
    },
    'stats': {
        'chapters': len(CHAPTERS), 'concepts': len(nodes),
        'chapters_with_learning_outcomes': sorted(c for c, o in outcomes_by_ch.items() if o),
    },
}
json.dump(graph, open('/root/audit/knowledge-graph-v2.json', 'w'), indent=2, default=list)

print(f"nodes={len(nodes)}  OPEN violations={len(violations)}  "
      f"closed-by-gloss={len(closed)}  previously-adjudicated={len(adjudicated)}  "
      f"redundant={len(redundant)}  orphans={len(orphans)}  dangling_refs={len(bad_refs)}")
print(f"chapters with learning outcomes: {graph['stats']['chapters_with_learning_outcomes']}\n")

print("=== PREREQUISITE VIOLATIONS (hard dependencies only) ===")
for v in graph['findings']['prerequisite_violations']:
    print(f"\nch{v['depends_from_chapter']} §{v['section']}  [{v['kind']}]  {v['concept'].upper()}")
    print(f"   {v['detail']}")
    print(f"   \"{v['quote'][:190]}\"")

print("\n\n=== REDUNDANT INTRODUCTIONS (same concept formally defined twice) ===")
for r in graph['findings']['redundant_introductions']:
    print(f"  {r['concept']:32} defined in chapters {r['chapters']}")

print("\n=== DANGLING BACKWARD CROSS-REFERENCES ===")
for b in graph['findings']['dangling_cross_references']:
    print(f"  ch{b['from_chapter']} §{b['location']}: {b['issue']}")
    print(f"      claim: \"{(b['claim'] or '')[:150]}\"")
