# Extraction spec (v2) — re-extraction after the fix pass

Same schema as the original audit, but the source has changed. **Read the
chapter from the local file, do not scrape anything.** Local markdown is now
the book's source of truth; the published site is behind it.

Your chapter file: `/root/audit/current/chapter-<NN>.md`

The book is an introductory database textbook for **business majors**, teaching
"concepts before syntax." You are extracting concept data to rebuild a
dependency graph that answers one question: *does any chapter rely on an idea
the book has not yet introduced?*

## Context you need

A round of fixes was just applied. The house rule they follow is
**one owning chapter per concept**: the chapter that first teaches a concept
defines it formally and holds the Key Terms entry; later chapters may use and
extend it, but reference back rather than re-defining. Several passages were
deliberately written as *inline glosses without glossary entries* for exactly
this reason.

Judge what you find on its own terms — do not assume a fix is present or
correct. If a chapter still relies on something it never introduces, report it.

## Step 1 — Read

Read `/root/audit/current/chapter-<NN>.md` in full, in order. Chapters end with
"Interactive Activities" containing AI study prompts. Those count as chapter
content for **usage**, but an activity prompt is never a **definition**.

## Step 2 — Emit JSON

Write `/root/audit/extractions_v2/chapter-<NN>.json`, matching this schema exactly:

```json
{
  "chapter_number": 4,
  "chapter_title": "...",
  "sections": ["4.1 Section title", "..."],
  "learning_outcomes": ["verbatim outcome text, or [] if none"],
  "key_terms": ["Candidate key", "Set"],

  "concepts_introduced": [
    {
      "name": "candidate key",
      "aliases": [],
      "type": "term | idea | skill",
      "formally_defined": true,
      "definition_location": "4.3",
      "definition_quote": "verbatim sentence that defines it",
      "first_mention_location": "4.3",
      "first_mention_quote": "verbatim sentence of earliest appearance",
      "in_key_terms": true
    }
  ],

  "concepts_assumed": [
    {
      "name": "foreign key",
      "strength": "hard | soft",
      "used_at": "4.4",
      "quote": "verbatim sentence where it is relied upon",
      "why_needed": "one sentence: why the passage is unintelligible without it",
      "glossed_in_place": false
    }
  ],

  "cross_references": [
    {
      "claim_text": "as we saw in Section 2.5",
      "location": "4.3",
      "direction": "backward | forward",
      "points_to_chapter": 2,
      "concept_referenced": "primary key"
    }
  ]
}
```

## Field guidance

**concepts_introduced** — concepts this chapter teaches. A concept explained
only informally still belongs here with `formally_defined: false`. A term used
but never explained anywhere in the chapter belongs in `concepts_assumed`.

**concepts_assumed** — concepts the chapter relies on but does not itself teach.
Domain concepts only, not general English or business vocabulary.

`strength`:
- **hard** — a reader who does not know this cannot understand the sentence.
- **soft** — it enriches the passage but the reader can proceed.

When torn, choose `soft` and explain in `why_needed`.

**`glossed_in_place`** (new in v2, important) — set `true` when the chapter
relies on a concept it does not own, BUT explains it well enough on the spot for
the reader to continue, typically with a pointer to the owning chapter. Example
shape: "Joins cost time. (A *join* is the operation that puts back together what
normalization split apart… Chapter 7 covers it properly.)"

Still record these as `concepts_assumed` with honest `strength` — the graph
needs to know the dependency exists. `glossed_in_place` records that the
dependency is *handled*, which is what distinguishes a closed gap from an open
one. Set it `false` when the concept is simply used with no explanation.

**cross_references** — explicit claims about other parts of the book ("in
Chapter 1", "as we saw earlier", "Section 2.5"). Capture verbatim. Do not try to
verify them; you only see one chapter.

## Rules

- Quote verbatim. Every quote must be findable by exact string search of the
  source file. Never paraphrase into a quote field.
- Use the chapter's own wording for `name`; put variants in `aliases`.
  Vocabulary drift is itself a finding.
- Valid JSON only. No trailing commas, no comments, no markdown fences.

## Return to the caller

Reply with ONLY a compact summary: chapter number, counts of introduced /
assumed-hard / assumed-soft / glossed-in-place / cross-references, and a
one-line note on anything that looks unresolved. Do not paste the JSON or the
chapter text back.
